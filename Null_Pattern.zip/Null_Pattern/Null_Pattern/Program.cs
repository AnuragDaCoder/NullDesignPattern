﻿


using Null_Pattern;

var cricketerType= CricketerFactory.GetCricketerType(150);
cricketerType.Message();

var cricketerType1 = CricketerFactory.GetCricketerType(-20);
cricketerType1.Message();