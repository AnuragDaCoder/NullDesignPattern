﻿
namespace Null_Pattern
{
    public interface ICricketerType
    {
        public void Message();
    }

    public class ExplosiveStriker : ICricketerType
    {
        public void Message()
        {
            Console.WriteLine("You fall under explosive category " +
                "!! Super");
        }
    }

    public class BestStriker : ICricketerType
    {
        public void Message()
        {
            Console.WriteLine("You fall under best category " +
                "!! Keep Improving !!");
        }
    }

    public class WeakStriker : ICricketerType
    {
        public void Message()
        {
            Console.WriteLine("You fall under weak category !! " +
                "If this continues you will be thrown out of team!!");
        }
    }


    public class NullStriker : ICricketerType
    {
        public void Message()
        {
            Console.WriteLine("you are not a cricketer!!");
        }

        private static ICricketerType instance = new NullStriker();
        public static ICricketerType Instance { get { return instance; } }
    }
    public static class CricketerFactory
    {
        public static ICricketerType GetCricketerType(int strikeRate)
        {
            if(strikeRate > 120)
            {
                return new ExplosiveStriker();
            }
            else if (strikeRate > 80 && strikeRate < 100)
            {
                return new BestStriker();
            }
            else if (strikeRate > 0 && strikeRate < 80)
            {
                return new WeakStriker();
            }
            else
            {
                return NullStriker.Instance;
            }
        }
    }
}
